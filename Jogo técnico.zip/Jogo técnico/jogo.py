import tkinter as tk
from tkinter import simpledialog
import random

def iniciar_jogo():
    global fase_atual
    fase_atual = 1
    proxima_fase_button.pack_forget()
    reiniciar_jogo_button.pack_forget()
    iniciar_fase(fase_atual)

def iniciar_fase(fase):
    result_text.delete(1.0, tk.END)
    result_text.insert(tk.END, f"Fase {fase}:\n")

    if fase == 1:
        result_text.insert(tk.END, "Você está diante de duas portas:\n")
        result_text.insert(tk.END, "1. Entrar pela majestosa porta de pedra\n")
        result_text.insert(tk.END, "2. Entrar pela deslumbrante porta de gemas\n")
        criar_botao_opcao(1, escolher_porta)
        criar_botao_opcao(2, escolher_porta)
    elif fase == 2:
        if fase_atual == fase_perdida:
            result_text.insert(tk.END, "Você foi pegar a chave, mas escorregou e caiu no abismo sombrio. Você morreu.\n")
            reiniciar_jogo_button.pack()
        else:
            result_text.insert(tk.END, "Você encontrou um baú cravejado de gemas, mas ele está trancado.\n")
            result_text.insert(tk.END, "Você percebe que a chave para abrir o baú está faltando e precisa explorar mais para encontrá-la.\n")
            criar_botao_opcao(1, fazer_pergunta)
            criar_botao_opcao(2, perder_jogo)
    elif fase == 3:
        result_text.insert(tk.END, "Você está à beira de um rio tranquilo e misterioso:\n")
        result_text.insert(tk.END, "1. Sente-se à beira do rio e medita\n")
        result_text.insert(tk.END, "2. Bebe da água do rio\n")
        criar_botao_opcao(1, escolher_rio)
        criar_botao_opcao(2, escolher_rio)
    elif fase == 4:
        result_text.insert(tk.END, "Você encontrou um dispositivo misterioso com um enigma:\n")
        result_text.insert(tk.END, "Qual é a resposta para o enigma?\n")
        criar_botao_opcao(1, responder_enigma)
    elif fase == 5:
        result_text.insert(tk.END, "Você está diante do guardião da Relíquia Sagrada:\n")
        result_text.insert(tk.END, "1. Responda ao enigma sagrado\n")
        result_text.insert(tk.END, "2. Aceite a prova de habilidade\n")
        criar_botao_opcao(1, escolher_guardiao)
        criar_botao_opcao(2, escolher_guardiao)
    elif fase == 6:
        result_text.insert(tk.END, "Parabéns! Você concluiu a jornada com sucesso!\n")
        proxima_fase_button.pack_forget()
        reiniciar_jogo_button.pack()

def criar_botao_opcao(opcao, comando):
    botao = tk.Button(result_window, text=f"{opcao}", command=lambda: comando(opcao))
    botao.pack()

def escolher_porta(porta):
    destruir_botoes_opcao()
    if porta == 1:
        iniciar_fase(2)
    elif porta == 2:
        iniciar_fase(3)

def fazer_pergunta():
    destruir_botoes_opcao()
    pergunta = simpledialog.askstring("Pergunta", "Digite sua pergunta:")
    result_text.insert(tk.END, f"A estátua murmura uma resposta enigmática para '{pergunta}': 'A verdade está nas estrelas e na quietude da mente.'\n")
    result_text.insert(tk.END, "A resposta do Oráculo ecoa em sua mente enquanto você continua sua jornada.\n")
    iniciar_fase(4)

def escolher_rio(opcao):
    destruir_botoes_opcao()
    if opcao == 1:
        result_text.insert(tk.END, "Você se senta à beira do rio, meditando profundamente e encontrando respostas para suas dúvidas.\n")
        result_text.insert(tk.END, "O espírito sorri, abençoando-o com sabedoria adicional para o desafio final.\n")
        iniciar_fase(5)
    elif opcao == 2:
        if fase_atual == fase_perdida:
            result_text.insert(tk.END, "Você bebe da água revitalizante, mas algo não parece certo...\n")
            result_text.insert(tk.END, "Você sente uma estranha fraqueza tomando conta de você...\n")
            result_text.insert(tk.END, "Você desmaia e falha nesta fase. Tente novamente!\n")
            proxima_fase_button.pack_forget()
            reiniciar_jogo_button.pack()
        else:
            result_text.insert(tk.END, "Você bebe da água revitalizante, sentindo uma onda de energia percorrer seu corpo.\n")
            result_text.insert(tk.END, "O espírito assente com aprovação, confiante em sua escolha.\n")
            iniciar_fase(5)

def responder_enigma():
    destruir_botoes_opcao()
    resposta_enigma = simpledialog.askstring("Enigma", "Qual é a sua resposta?").lower()

    if resposta_enigma == "buraco":
        iniciar_fase(6)
    else:
        result_text.insert(tk.END, "A resposta está incorreta. O dispositivo emite uma faísca e você é empurrado para trás.\n")
        result_text.insert(tk.END, "Por sorte, você cai em uma plataforma secreta que o leva ao próximo desafio.\n")
        iniciar_fase(5)

def escolher_guardiao(opcao):
    destruir_botoes_opcao()
    if opcao == 1:
        iniciar_fase(6)
    elif opcao == 2:
        result_text.insert(tk.END, "Você aceita a prova de habilidade com determinação, superando todos os obstáculos com maestria.\n")
        result_text.insert(tk.END, "Impressionado por sua bravura, o guardião lhe confia a Relíquia Sagrada, reconhecendo sua força interior.\n")
        result_text.insert(tk.END, "Você sai do templo, sabendo que seu nome será lembrado nas lendas como alguém que enfrentou o impossível.\n")
        proxima_fase_button.pack_forget()
        reiniciar_jogo_button.pack()

def destruir_botoes_opcao():
    for widget in result_window.winfo_children():
        if isinstance(widget, tk.Button):
            widget.pack_forget()

def perder_jogo(opcao):
    global fase_atual
    fase_atual = fase_perdida
    iniciar_fase(fase_atual)

fase_atual = 0
fase_perdida = 2  # Você vai perder na fase 2

result_window = tk.Tk()
result_window.title("Jornada das Relíquias Ancestrais")

result_text = tk.Text(result_window, height=20, width=60)
result_text.pack()

iniciar_jogo_button = tk.Button(result_window, text="Iniciar Jogo", command=iniciar_jogo)
proxima_fase_button = tk.Button(result_window, text="Próxima Fase", command=iniciar_jogo)
reiniciar_jogo_button = tk.Button(result_window, text="Reiniciar Jogo", command=iniciar_jogo)

iniciar_jogo_button.pack()

result_window.mainloop()
